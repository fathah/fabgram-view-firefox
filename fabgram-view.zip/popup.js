
document.addEventListener("DOMContentLoaded", function() {
    var myButton = document.getElementById("myButton");
    
    myButton.addEventListener("click", myFunction);
  });
  
  function myFunction() {
    console.log("Button clicked! Calling myFunction...");
    // Add your custom functionality here
  }